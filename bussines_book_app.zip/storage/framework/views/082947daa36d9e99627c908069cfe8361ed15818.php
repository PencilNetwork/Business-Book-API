<form method='post' action  ='<?php echo e(url("/api/offers/$offer->id")); ?>' enctype="multipart/form-data" >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'caption'  type = 'text' value="<?php echo e($offer->caption); ?>"/>
    <input name = 'image' type = 'file' value="<?php echo e($offer->image); ?>"/>

    <input type = 'text' name = 'bussines_id' value= "<?php echo e($offer->bussines_id); ?>"/>
    <input type = 'submit' />
</form>