<form method='post' action  ='<?php echo e(url("/api/searchers/login")); ?>'  >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'name'  type = 'text' value="<?php echo e(old('name')); ?>"/><br> 
    <input name = 'social_id' type = 'text' value="<?php echo e(old('social_id')); ?>"/><br>
    <input name = 'email' type = 'text' value="<?php echo e(old('email')); ?>"/>
    <input name = 'token' type = 'text' value="<?php echo e(old('token')); ?>"/>
    <input type = 'submit' />
</form>