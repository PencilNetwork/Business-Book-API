<form method='post' action  ='<?php echo e(url("/api/search/bussines_name")); ?>'  >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'searcher_id'  type = 'text' value="1"/><br> 
    <input name = 'bussines_name'  type = 'text' /><br> 
    
    <input type = 'submit' />
</form>