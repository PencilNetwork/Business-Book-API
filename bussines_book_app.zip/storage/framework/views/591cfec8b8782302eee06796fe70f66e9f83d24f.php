<form method='post' action  ='<?php echo e(url("/api/owner/login")); ?>'  >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'name'  type = 'text'  placeholder="name" /><br> 
    <!-- <input name = 'email'  type = 'text' value="<?php echo e(old('email')); ?>" placeholder="email" /><br>  -->
    <input name = 'password' type = 'text' value="<?php echo e(old('password')); ?>" placeholder="password" /><br>
    <input name = 'token' type = 'text' value="<?php echo e(old('token')); ?>" placeholder="token" />
    <input type = 'submit' />
</form>