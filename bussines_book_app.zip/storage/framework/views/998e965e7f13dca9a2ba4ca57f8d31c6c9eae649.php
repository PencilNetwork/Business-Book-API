<form method='post' action  ='<?php echo e(url("/api/files/$file->id")); ?>' enctype="multipart/form-data" >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'bussines_id'  type = 'text' value="<?php echo e($file->bussines_id); ?>"/>
    <input name = 'image' type = 'file' value="<?php echo e(asset('images'.$file->image )); ?>"/>
    <input type = 'submit' />
</form>


