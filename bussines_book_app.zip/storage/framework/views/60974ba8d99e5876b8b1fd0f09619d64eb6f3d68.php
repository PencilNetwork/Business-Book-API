<form method='post' action  ='<?php echo e(url("/api/bussines/$bussines->id")); ?>' enctype="multipart/form-data" >
    <!-- <?php echo e(method_field('post')); ?> -->
    <?php echo e(csrf_field()); ?>

    <input name = 'name'  type = 'text' value="<?php echo e($bussines->name); ?>"/>
    <input name = 'image' type = 'file' value="<?php echo e(asset('/images/'.$bussines->image )); ?>"/>
    <input type = 'text' name = 'description'  value="<?php echo e($bussines->description); ?>"/>
    <input name = 'logo' type = 'file' />
    <input type = 'text' name = 'contact_number' value="<?php echo e($bussines->contact_number); ?>" />
    <input type = 'text' name = 'city_id' value="<?php echo e($bussines->city_id); ?>"/>
    <input type = 'text' name = 'regoin_id' value="<?php echo e($bussines->regoin_id); ?>"/>
    <input type = 'text' name = 'address' value="<?php echo e($bussines->address); ?>"/>
    <input type = 'text' name = 'langitude' value="<?php echo e($bussines->langitude); ?>"/>
    <input type = 'text' name = 'lattitude' value="<?php echo e($bussines->lattitude); ?>"/>
    <input type = 'text' name = 'category_id' value = '1' value="$bussines->category_id }}"/>
    <input type = 'text' name = 'owner_id' value = '1' value="<?php echo e($bussines->owner); ?>"/>
    <input type = 'submit' />
</form>
<img src="<?php echo e($bussines->image); ?>"  alt = 'image'> 