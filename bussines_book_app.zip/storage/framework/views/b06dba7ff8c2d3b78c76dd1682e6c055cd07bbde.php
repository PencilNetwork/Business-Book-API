<form method='post' action  ='<?php echo e(url("/api/offer/search")); ?>'  >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'bussines_name'  type = 'text'  placeholder="bussines_name " /><br> 
    <input name = 'city_id'  type = 'text' placeholder="province_name" /><br> 
    <input name = 'regoin_id'  type = 'text'  placeholder="regoin_name" /><br> 
    <input name = 'category_id'  type = 'text' placeholder="category_id" /><br> 
    
    <input type = 'submit' />
</form>