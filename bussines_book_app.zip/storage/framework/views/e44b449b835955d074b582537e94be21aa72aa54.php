<form method='post' action  ='<?php echo e(url("/api/interests")); ?>' >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'searcher_id'  type = 'text' value="1"/>
    <input name = 'categories' type = 'text' value="<?php echo e(old('categories')); ?>"/>
    <input name = 'city' type = 'text' value="<?php echo e(old('city')); ?>"/>
    <input name = 'regoins' type = 'text' value="<?php echo e(old('regoins')); ?>"/>
    <input type = 'submit' />
</form>