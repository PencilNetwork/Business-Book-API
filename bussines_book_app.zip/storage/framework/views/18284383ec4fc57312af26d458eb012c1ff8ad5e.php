<form method='post' action  ='<?php echo e(url("/api/bussines/search/category")); ?>'  >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'searcher_id'  type = 'text' value="1"/><br> 
    <input name = 'category_id'  type = 'text' /><br> 
    
    <input type = 'submit' />
</form>