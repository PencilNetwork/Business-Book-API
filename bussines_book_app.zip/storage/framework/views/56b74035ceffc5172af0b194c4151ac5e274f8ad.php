<form method = 'post' action="<?php echo e(url('/api/owner/reset')); ?>">
		<?php echo e(csrf_field()); ?>

	<input type = 'hidden' name = 'email' value="<?php echo e($email); ?>" > 
	<input type = 'text' name = 'password' placeholder="Enter New password"> 
	<input type = 'submit' value = 'Reset' > 
</form>