<form method='post' action  ='<?php echo e(url("/api/bussines_search")); ?>'  >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'bussines_name'  type = 'text'  placeholder="bussines_name " /><br> 
    <input name = 'city_id'  type = 'text' placeholder="city_id" /><br> 
    <input name = 'regoin_id'  type = 'text'  placeholder="regoin_id" /><br> 
    <input name = 'category_id'  type = 'text' placeholder="category_id" /><br> 
    <input type = 'submit' />
</form>