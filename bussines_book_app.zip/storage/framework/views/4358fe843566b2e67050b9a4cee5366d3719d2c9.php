<form method='post' action  ='<?php echo e(url("/api/favoirtes/1/2")); ?>' >
    <?php echo e(method_field('DELETE')); ?>

    <?php echo e(csrf_field()); ?>

    
    <input type = 'submit' />
</form>