<form method='POST' action  ='<?php echo e(url("/api/files/$file->id")); ?>'>
    <?php echo e(method_field('DELETE')); ?>

    <?php echo e(csrf_field()); ?>

    <input type = 'submit' value = 'delete' />
</form>