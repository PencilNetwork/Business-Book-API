<form method='post' action  ='<?php echo e(url("/api/offers")); ?>' enctype="multipart/form-data" >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'caption'  type = 'text' value="<?php echo e(old('caption')); ?>"/>
    <input name = 'image' type = 'file' value="<?php echo e(old('image')); ?>"/>

    <input type = 'text' name = 'bussines_id' value=7 }}/>
    <input type = 'submit' />
</form>