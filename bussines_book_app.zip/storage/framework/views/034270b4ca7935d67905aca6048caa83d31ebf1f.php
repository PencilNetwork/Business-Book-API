<!DOCTYPE html>
<html>
<head>
    <title>Welcome  <?php echo e($email); ?></title>
</head>
 
<body>
<h2>Reset Password</h2>
<br/>
<!-- <a href = "<?php echo e(url('/api/owner/')); ?>" > reset pass </a> -->
	<form method = 'post' action="<?php echo e(url('/api/owner/reset')); ?>">
		
		<input type = 'text' name = 'email' value="<?php echo e($email); ?>" > 
		<input type = 'text' name = 'password'> 
		<input type = 'submit' value = 'Reset' > 
	</form>
</body>
 
</html>