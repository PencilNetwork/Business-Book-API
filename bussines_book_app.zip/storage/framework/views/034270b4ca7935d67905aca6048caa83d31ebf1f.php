<!DOCTYPE html>
<html>
<head>
    <title>Welcome  <?php echo e($email); ?></title>
</head>
 
<body>
<h2>Reset Password</h2>
<br/>
<!-- <a href = "<?php echo e(url('/api/owner/reset')); ?>" > reset pass </a> -->
<form method = 'get' action="<?php echo e(url('/api/owner/reset_page')); ?>">

	<input type = 'hidden'  name = 'email' value="<?php echo e($email); ?>" > 
	<input type = 'submit' value = 'Reset' > 
</form>
	
</body>
 
</html>