<form method='post' action  ='<?php echo e(url("/api/offers/$offer->id")); ?>'>
    <?php echo e(method_field('DELETE')); ?>

    <?php echo e(csrf_field()); ?>

    <input type = 'submit' value = 'delete' />
</form>