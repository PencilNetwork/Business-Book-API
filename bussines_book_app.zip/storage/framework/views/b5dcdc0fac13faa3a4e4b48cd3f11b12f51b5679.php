<form method='post' action  ='<?php echo e(url("/api/interests/$interest->id")); ?>' enctype="multipart/form-data" >
    <!-- <?php echo e(method_field('post')); ?> -->
    <?php echo e(csrf_field()); ?>

    <input name = 'searcher_id'  type = 'text' value="<?php echo e($interest->searcher_id); ?>"/>
    <input name = 'categories_ids' type = 'text' value="<?php echo e($interest->categories_ids); ?>"/>
    <input type = 'text' name = 'city_id'  value="<?php echo e($interest->city_id); ?>"/>
    <input type = 'text' name = 'regoins_ids'  value="<?php echo e($interest->regoins_ids); ?>"/>
    <input type = 'submit' />
</form>
