<form method='post' action  ='<?php echo e(url("/api/bussines/store")); ?>' enctype="multipart/form-data" >
    <?php echo e(method_field('POST')); ?>

    <?php echo e(csrf_field()); ?>

    <input name = 'name'  type = 'text' value="<?php echo e(old('name')); ?>"/>
    <input name = 'image' type = 'file' value="<?php echo e(old('image')); ?>"/>
    <input type = 'text' name = 'description' value="<?php echo e(old('description')); ?>" />
    <input name = 'logo' type = 'file' value="<?php echo e(old('logo')); ?>"/>
    <input type = 'text' name = 'contact_number' value="<?php echo e(old('contact_number')); ?>" />
    <input type = 'text' name = 'city_id' value="<?php echo e(old('city_id')); ?>"/>
    <input type = 'text' name = 'regoin_id' value="<?php echo e(old('regoin_id')); ?>"/>
    <input type = 'text' name = 'address' value="<?php echo e(old('address')); ?>"/>
    <input type = 'text' name = 'langitude' value="<?php echo e(old('langitude')); ?>"/>
    <input type = 'text' name = 'lattitude' value="<?php echo e(old('lattitude')); ?>"/>
    <input type = 'text' name = 'category_id' value = '1' value="<?php echo e(old('category_id')); ?>"/>
    <input type = 'text' name = 'owner_id' value = '1' value="<?php echo e(old('owner')); ?>"/>
    <input type = 'submit' />
</form>