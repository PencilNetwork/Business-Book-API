<form method = 'post' action="{{url('/api/owner/reset')}}">
		{{csrf_field()}}
	<input type = 'hidden' name = 'email' value="{{$email}}" > 
	<input type = 'text' name = 'password' placeholder="Enter New password"> 
	<input type = 'submit' value = 'Reset' > 
</form>